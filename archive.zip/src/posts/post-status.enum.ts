export enum PostStatus {
  JOY = 'JOY',
  HAPPY = 'HAPPY',
  FUNNY = 'FUNNY',
  FEAR = 'FEAR',
  SAD = 'SAD',
  DISGUST = 'DISGUST',
  ANGER = 'ANGER',
}
